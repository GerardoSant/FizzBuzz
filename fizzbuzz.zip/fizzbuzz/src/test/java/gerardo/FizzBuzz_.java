package gerardo;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

public class FizzBuzz_ {

    @Test
    public void should_return_1_given_1() {

        assertThat(FizzBuzz.of(1)).isEqualTo("1");
       // assertEquals("1", actual);
    }
    @Test
    public void should_return_2_given_2() {

        assertThat(FizzBuzz.of(2)).isEqualTo("2");
        // assertEquals("1", actual);
    }
    @Test
    public void given_a_number_multiple_of_3_should_return_fizz() {

        assertThat(FizzBuzz.of(3)).isEqualTo("fizz");
        assertThat(FizzBuzz.of(6)).isEqualTo("fizz");
        // assertEquals("1", actual);
    }

    @Test
    public void given_a_number_multiple_of_5_should_return_buzz() {

        assertThat(FizzBuzz.of(5)).isEqualTo("buzz");
        assertThat(FizzBuzz.of(10)).isEqualTo("buzz");
        // assertEquals("1", actual);
    }

    @Test
    public void given_a_number_multiple_of_15_should_return_fizzbuzz() {

        assertThat(FizzBuzz.of(15)).isEqualTo("fizzbuzz");
        assertThat(FizzBuzz.of(30)).isEqualTo("fizzbuzz");
        // assertEquals("1", actual);
    }








}
