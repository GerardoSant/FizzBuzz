package gerardo;


import org.junit.Test;

import java.lang.reflect.Array;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

public class JosephPermutation_ {

    @Test
    public void should_return_empty_given_empty(){
        assertThat(Arrays.equals(new int[]{} , JosephPermutation.of(new int[]{})));
    }

    @Test
    public void should_return_1_given_1(){
        assertThat(Arrays.equals(new int[]{1} , JosephPermutation.of(new int[]{1})));
    }

    @Test
    public void should_return_2_given_2(){
        assertThat(Arrays.equals(new int[]{4,3,2} , JosephPermutation.of(new int[]{2})));
    }




}
